
import Menu from "./componentes/Menu";
import Inicio from "./componentes/Inicio";
import Pedido from "./componentes/Pedido";
import Pedidos from "./componentes/Pedidos";
import Producto from "./componentes/Producto";
import Productos from "./componentes/Productos";
import { Routes, Route } from "react-router-dom";
import Empleados from "./componentes/Empleados";
import Empleado from "./componentes/Empleado";
import Departamentos from "./componentes/Departamentos";
import Departamento from "./componentes/Departamento";
import Clientes from "./componentes/Clientes";
import Cliente from "./componentes/Cliente";
import Almacen from "./componentes/Almacen";
import Almacenes from "./componentes/Almacenes";
import Inventarios from "./componentes/Inventarios";
import Inventario from "./componentes/Inventario";
import Items from "./componentes/Items"
import Item from "./componentes/Item"

function App() {
  return (
    <>
      <Menu/>
        <div className="container text-center">
          <Routes>
            <Route path='/' element={<Inicio></Inicio>} ></Route>
            <Route path='/productos' element={<Productos></Productos>} ></Route>
            <Route path='/almacenes' element={<Almacenes></Almacenes>} ></Route>
            <Route path='/inventarios' element={<Inventarios></Inventarios>} ></Route>
            <Route path='/pedidos' element={<Pedidos></Pedidos>} ></Route>
            <Route path='/empleados' element={<Empleados></Empleados>} ></Route>
            <Route path='/empleado/:id' element={<Empleado></Empleado>} ></Route>
            <Route path='/departamentos' element={<Departamentos></Departamentos>}></Route>
            <Route path='/clientes' element={<Clientes></Clientes>}></Route>
            <Route path='/cliente/:id' element={<Cliente></Cliente>} ></Route>
            <Route path='/departamento/:depto_id' element={<Departamento/>}></Route>
            <Route path='/almacen/:id' element={<Almacen></Almacen>} ></Route>
            <Route path="/inventario/:idProducto/:idAlmacen" element={<Inventario></Inventario>}></Route>
            <Route path="/producto/:id" element={<Producto></Producto>}></Route>
            <Route path='/pedidos' element={<Pedidos></Pedidos>} ></Route>
            <Route path="/pedido/:id" element={<Pedido></Pedido>}></Route>
            <Route path="/items/:pedido_id" element={<Items></Items>}></Route>
            <Route path="/item/:pedido_id/:item_id" element={<Item></Item>}></Route>
          </Routes>
        </div>

    </>
  );
}

export default App;
