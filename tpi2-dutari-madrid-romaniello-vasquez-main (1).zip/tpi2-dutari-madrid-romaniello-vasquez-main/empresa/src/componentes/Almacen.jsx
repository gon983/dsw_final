import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { useParams } from "react-router-dom";



const Almacen = () => {
    //Definicion de estado del componente almacen y de otras funciones necesarias para la funcionalidad del componente
    const [almacen, setAlmacen] = useState({});
    const {register, setValue, formState:{errors}, handleSubmit} = useForm();
    const navigate = useNavigate();
    const {id} = useParams();

    //Funcion para volver al componentes almacenes
    const volver = () =>{
        navigate('/almacenes');
    };

    const getAlmacen = async (id) => {
        if (id > 0) {
        const {data} = await axios.get(`http://localhost:2525/almacenes/${id}`)
        
        setAlmacen(data);
        setValue('direccion', data.direccion);
        setValue('fecha_de_establecimiento', data.fecha_de_establecimiento);
        setValue('telefono', data.telefono);
    }};

    useEffect(()=>{
        getAlmacen(id);
    },
    []
    )

    
    //Funcion para crear o actualizar un almacen seleccionado por el usuario
    const onSubmit = async(data) =>{
        if (id > 0){
            await axios.put(`http://localhost:2525/almacenes/${id}`, data)
        }
        else{
            await axios.post(`http://localhost:2525/almacenes`, data);
            
        };
        volver();
    }
    

    return(
    <form onSubmit={handleSubmit(onSubmit)} className='mt-5'>
      <h1 className='mb-5'>Almacen {id > 0? almacen.direccion : 'nuevo'}</h1>
        <div className="row mt-3">
            <div className="col-4 text-end">
                <label htmlFor="direccion">Dirección del almacen:</label>
            </div>
            <div className="col-8 text-start">
                <input type="text" 
                    className='form-control'
                    {...register('direccion', {required: 'La dirección es requerida'})}
                />
                {errors.direccion && <span className='text-danger'>{errors.direccion.message}</span>}
            </div>
        </div>

        <div className="row mt-3">
            <div className="col-4 text-end">
                <label htmlFor="fecha_de_establecimiento">Fecha del establecimiento:</label>
            </div>
            <div className="col-8 text-start">
                <input type="text" 
                    className='form-control'
                    {...register('fecha_de_establecimiento', {required: 'La fecha de establecimiento es requerida'})}
                />
                {errors.fecha_de_establecimiento && <span className='text-danger'>{errors.fecha_de_establecimiento.message}</span>}
            </div>
        </div>

        <div className="row mt-3">
            <div className="col-4 text-end">
                <label htmlFor="telefono">Telefono:</label>
            </div>
            <div className="col-8 text-start">
                <input type="text" 
                    className='form-control'
                    {...register('telefono', {required: 'El número de télefono es requerido', 
                        validate: (value) => {return !isNaN(value) || 'Debe ser numérico'} })}
                    />
                    {errors.telefono && <span className='text-danger'>{errors.telefono.message}</span>}
            </div>
        </div>

        <div className="mt-5 mb-5">
            <button type="button" className="btn btn-danger" onClick={()=>{volver()}}>Cancelar</button>
            <input type="submit" value={id > 0 ? 'Actualizar' : 'Crear'} className="btn btn-success"></input>
        </div>

    </form>)
};

export default Almacen;