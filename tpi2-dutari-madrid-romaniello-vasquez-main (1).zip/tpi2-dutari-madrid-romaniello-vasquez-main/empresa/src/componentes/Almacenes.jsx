import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import axios from "axios";
import { Link } from "react-router-dom";

const Almacenes = () => {
    //Deficion del estado del componente almacenes
    const [almacenes, setAlmacenes] = useState(null);
    const {register, handleSubmit} = useForm();

    //Proceder con la carga de almacenes
    const getAlmacenes = async (queires = '') =>{
        const {data} = await axios.get(`http://localhost:2525/almacenes?${queires}`);
        setAlmacenes(data);
    };

    //Funcion para mostrar por pantalla los datos del almacen buscado por direccion
    const onSubmit = (data) => {
        let queries = [];
        data.direccion && queries.push(`direccion=${data.direccion}`);
        getAlmacenes(queries.join('&'));


    };

    //Funcion para borrar un almacenamiento
    const deleteAlmacen = async (id) => {
        if(window.confirm('¿Deseas confiar el borrado del almacenamiento?')){
            await axios.delete(`http://localhost:2525/almacenes/${id}`)
            getAlmacenes('');
        };
    };


    // Llamar a la funcion para cargar almacenes al momento de que se renderize la pagina
    useEffect(()=>{
        getAlmacenes();
    },
    []
    );

    //Representacion del almacen en la pagina
    return(<div className="text-start">
            <h1 className="text-center">Almacenes <i className="bi bi-box-seam"></i></h1>
            {/* Aquí se insertaría el formulario para realizar la busqueda de un almacen */}
            <form onSubmit={handleSubmit(onSubmit)}>
        <fieldset>
        
        <div className="row">
          <div className="col-5">
            <input type="text" 
            {...register('direccion')}
            placeholder="Dirección"
            className="form-control"/>
          </div>
          <div className="col-2">
            <button type="submit" className="btn btn-info">
              Buscar
              <i className="bi bi-search ms-2"></i>
            </button>
          </div>
        </div>
        </fieldset>
      </form>

        {/* Aquí se insertaría una tabla para el listado de los almacenes y su gestion correspondiente*/}
            
        <table className="table table-striped  mt-5">
         <thead className="table-primary font-monospace">
            <tr>
                <th scope="col">Dirección</th>
                <th scope="col">Fecha de establecimiento</th>
                <th scope="col">Número de teléfono</th>
                <th scope="col"><Link className="btn" to='/almacen/0'><i className="bi bi-plus-circle"></i>Agregar un nuevo almacen</Link></th>
            </tr>
         </thead>
        <tbody>
          {almacenes &&
            almacenes.map((alm) => {
              return (
                <tr className="table-warning" key={alm.id} >
                  <td >{alm.direccion}</td>
                  <td >{alm.fecha_de_establecimiento}</td>
                  <td >{alm.telefono}</td>
                  <td>
                    <button
                      className="btn btn-default"
                      onClick={() => deleteAlmacen(alm.id)}
                    >
                      <i className="bi bi-trash-fill text-danger"></i>
                    </button>
                    <Link className="btn btn-default" to={`/almacen/${alm.id}`} >
                        <i className="bi bi-pencil-square text-primary"></i>
                    </Link>
                  </td>
                </tr>
              );
            })}
        </tbody>
      </table>
    </div>
    )
};

export default Almacenes;