import { useForm } from "react-hook-form";
import { useNavigate, useParams } from "react-router-dom";
import axios from "axios";
import { useEffect, useState } from "react";

// ME QUEDA LA DUDA DE COMO SE MANEJAN LOS ID SI MI PK NO ES AUTOINCREMENTAL

function Departamento(){
    const {depto_id} = useParams()
    const navigate = useNavigate()
    const {register, handleSubmit, setValue, formState: {errors}} = useForm()
    const [departamento, setDepartamento] = useState({}) 

    useEffect(() => {
        getDepartamento(depto_id);
    }, []);

    function volver(){
        navigate('/departamentos')
    }

    
    async function onSubmit(data){
        if (depto_id > 0) {
            await axios.put(`http://localhost:2525/departamento/${depto_id}`, data)
        } else {
            await axios.post(`http://localhost:2525/departamento/`, data)
        }
        volver()
    }

    async function getDepartamento(depto_id){
        if(depto_id>0){

            const {data} = await axios.get(`http://localhost:2525/departamento/${depto_id}`)
            setDepartamento(data)
            // setear valores iniciales
            setValue('nombre', data.nombre)
            setValue('fecha_fundacion', data.fecha_fundacion)
        }    
    }



    return (
        <>
        <form onSubmit={handleSubmit(onSubmit)}>
        <div className="row mt-3">
            {departamento && <h1>Departamento: {depto_id > 0? departamento.nombre : 'Nuevo'}</h1>}
        </div>

        <div className="row text-center mt-5">
            <label className="col-3 h5"> Nombre: </label>
            <div className="col-5">
            <input type="text" className="form-control col-3 text-start" {...register('nombre', {required: 'El nombre es requerido'})}></input>
            {errors.nombre && <span className='text-danger'>{errors.nombre.message}</span>}
            </div>
        </div>

        <div className="row mt-3">
            <label className="col-3 h5"> Fecha de Creacion:</label>
            <div className="col-5">
            <input type="text" className="form-control col-3 text-start" {...register('fecha_fundacion', {required: 'La fecha de fundacion es requerida'})}></input>
            {errors.fecha_fundacion && <span className="text-danger">{errors.nombre.message}</span>}
            </div>
            
        </div>

        <div className="row mt-4 justify-content-center">
            <button type="submit" className="btn btn-success col-1">{depto_id > 0?  'Actualizar' :'Crear'}</button>
            <button className="btn btn-danger col-1" onClick={volver} >Cancelar</button>
        </div>
        
        </form>
        </>
    )
}
export default Departamento
