import { useState, useEffect } from 'react'
import axios from 'axios'
import { Link } from 'react-router-dom'
import { useForm } from 'react-hook-form'

function Departamentos() {
    const [departamentos, setDepartamentos] = useState(null)
    const { register, handleSubmit } = useForm()


    useEffect(() => { getDepartamentos() }, [])

    async function onSubmit(data) {
        let query = [];
        if (data.nombre) {
            query.push(`nombre=${data.nombre}`);
        }
        await getDepartamentos(query.join('&'));
    }

    async function getDepartamentos(queries = '') {
        const { data } = await axios.get(`http://localhost:2525/departamentos?${queries}`)
        setDepartamentos(data)
    }

    async function deleteDepartamento(depto_id) {
        if (window.confirm('¿Desea eliminar el departamento?')) {
            await axios.delete(`http://localhost:2525/departamento/${depto_id}`)
            getDepartamentos()
        }


    }

    return (
        
            <div className="text-start">

                <h1 className="text-center">Departamentos</h1>

                <form onSubmit={handleSubmit(onSubmit)}>
                    <fieldset>
                        <div className="row">
                            <div className='col-5'>

                                <input
                                    type="text"
                                    {...register('nombre')}
                                    placeholder="Nombre"
                                    className="form-control"
                                />
                            </div>
                            <div className='col-2'>
                            <button type="submit" className="btn btn-info">Buscar
                            <i className="bi bi-search ms-2"></i>
                            </button>
                            </div>
                            
                        </div>
                    </fieldset>
                </form>


                <div>
                    <table className='table table-striped  mt-5'>
                        <thead className='table-primary font-monospace'>
                            <tr>
                                <th>Id</th>
                                <th>Nombre</th>
                                <th>Fecha Creacion</th>
                                <th>
                                    <Link className='btn' to={'/departamento/0'}>
                                        <i className="bi bi-plus-square"> Nuevo Departamento</i>
                                    </Link>
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            {/* {depto_id: 1, nombre: "Ventas", fecha_fundacion:"1986-03-21"}, */}
                            {departamentos && departamentos.map((d) => {
                                return (
                                    <tr key={d.depto_id} className='table-warning'>
                                        <td>{d.depto_id}</td>
                                        <td>{d.nombre}</td>
                                        <td>{d.fecha_fundacion}</td>
                                        <td>
                                            {/* boton para eliminar */}
                                            <button className="btn btn-default" onClick={() => deleteDepartamento(d.depto_id)}>
                                                <i className="bi bi-trash text-danger"></i>
                                            </button>
                                            {/* link a cada departamento particular */}
                                            <Link className="btn btn-default" to={`/departamento/${d.depto_id}`}>
                                                <i className="bi bi-pencil text-primary"></i>
                                            </Link>

                                        </td>
                                    </tr>
                                )
                            }

                            )}

                        </tbody>
                    </table>
                </div>
            </div>

        
            )

}

            export default Departamentos