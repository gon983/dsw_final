function Inicio() {
    return (
        <>
            <div className="mt-5 mb-5">
                <h1 className="text-center"> La Empresa! </h1>
                <h2 className="text-center"> Bienvenido al TPI de desarrollo de software.</h2>
            </div>
            <div className="container text-center">
                <ul className="list-group">
                    <li className="list-group-item">Integrantes <i className="bi bi-people"></i></li>
                    <li className="list-group-item">Dutari Gonzalo</li>
                    <li className="list-group-item">Madrid Marcelo</li>
                    <li className="list-group-item">Romaniello Lucas</li>
                    <li className="list-group-item">Vazques Fernando</li>
                </ul>
            </div>


        </>
    )
}

export default Inicio;