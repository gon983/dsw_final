import axios from "axios";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { useNavigate, useParams } from "react-router-dom";
import { useEffect } from "react";

const Inventario = ()=>{
    //Definicion del estado del inventario y de funciones para su gestion
    const [inventario, setInventario] = useState({});
    const {register, setValue, handleSubmit, formState:{errors}} =  useForm();
    const navigate = useNavigate();
    const {idProducto, idAlmacen} = useParams();
    const [productoid, setIdProducto] = useState(null);
    const [almacenid, setIdAlmacen] = useState(null);
    const [productos, setProductos] = useState(null);
    const [almacenes, setAlmacenes] = useState(null);

    //recuperar los datos del inventario acorde a su primary key
    const getInventario = async (idPro, idAlm) => {
        if (idPro > 0){
        const {data} = await axios.get(`http://localhost:2525/inventario/${idPro}/${idAlm}`);
        setInventario(data);
        setValue('id_producto', data.id_producto);
        setValue('id_almacen', data.id_almacen);
        setValue('cantidad_en_stock', data.cantidad_en_stock);
        setValue('fecha_de_restock', data.fecha_de_restock);
        setValue('nombre_provedor_producto', data.nombre_provedor_producto);

        setIdProducto(data.id_producto);
        setIdAlmacen(data.id_almacen);}
    };

    //recuperar los datos de los productos
    const getProducto = async () => {
        const { data } = await axios.get('http://localhost:2525/productos');
        setProductos(data);
    ;}


    //recuperar los datos de los almacenes
    const getAlmacen = async () => {
        const { data } = await axios.get('http://localhost:2525/almacenes');
        setAlmacenes(data)}
    ;

    useEffect(()=>{
        getInventario(idProducto, idAlmacen);
        getProducto();
        getAlmacen();
    },[])

    //Definicion de funcion para volver al componente inventarios y asi mostrar el listado
    const volver = () => {
        navigate('/inventarios');
    };

    //Defincion de funcion para la actualizacion o creacion de inventarios

    const onSubmit= async (data)=>{
        if (idProducto > 0){
            await axios.put(`http://localhost:2525/inventario/${idProducto}/${idAlmacen}`, data)
        }
        else{
            await axios.post(`http://localhost:2525/inventario`, data)
        };
        volver();
    };


    //Representacion visual del componente
    return(
        <form onSubmit={handleSubmit(onSubmit)} className="mt-5">
            <h1 className='mb-5'>Inventario: {idProducto > 0? inventario.nombre : 'Nuevo'}</h1>
            <div className="row mt-3">
                <div className="col-4 text-end">
                    <label htmlFor="cantidad_en_stock">Cantidad en stock:</label>
                </div>
                <div className="col-8 text-start">
                    <input type="text" 
                    className='form-control'
                    {...register('cantidad_en_stock', {required: 'La cantidad es requerida', 
                        validate: (value) => {return !isNaN(value) || 'Debe ser numérico'} })}
                    />
                    {errors.cantidad_en_stock && <span className='text-danger'>{errors.cantidad_en_stock.message}</span>}
                </div>
            </div>
           
            <div className="row mt-3">
                <div className="col-4 text-end">
                    <label htmlFor="fecha_de_restock">Fecha de restock:</label>
                </div>
                <div className="col-8 text-start">
                    <input type="text" 
                    className='form-control'
                    {...register('fecha_de_restock', {required: 'La fecha de restock es requerido'})}
                    />
                    {errors.fecha_de_restock && <span className='text-danger'>{errors.fecha_de_restock.message}</span>}
                </div>
            </div>

            <div className="row mt-3">
                <div className="col-4 text-end">
                    <label htmlFor="nombre_provedor_producto">Nombre del provedor del producto:</label>
                </div>
                <div className="col-8 text-start">
                    <input type="text" 
                    className='form-control'
                    {...register('nombre_provedor_producto', {required: 'El nombre del provedor es requerido'})}
                    />
                    {errors.nombre_provedor_producto && <span className='text-danger'>{errors.nombre_provedor_producto.message}</span>}
                </div>
            </div>
                        
            
            <div className="row mt-3">
                <div className="col-4 text-end">
                    <label htmlFor="id_producto">Producto :</label>
                </div>
                <div className="col-8 text-start">
                    <select className="form-select"
                        defaultValue={productoid}
                        onChange={(e) => { setIdProducto(e.target.value) }}
                        {...register('id_producto')}>
                        <option value='0'>Todos los productos</option>
                        {productos && productos.map(pro => <option key={pro.id} value={pro.id} >{pro.nombre}</option>)}
                    </select>
                </div>
            </div>

            
            <div className="row mt-3">
                <div className="col-4 text-end">
                    <label htmlFor="id_almacen">Almacen :</label>
                </div>
                <div className="col-8 text-start">
                    <select className="form-select"
                        defaultValue={almacenid}
                        onChange={(e) => { setIdAlmacen(e.target.value) }}
                        {...register('id_almacen')}>
                        <option value='0'>Todos los almacenes</option>
                        {almacenes && almacenes.map(alm => <option key={alm.id} value={alm.id} >{alm.direccion}</option>)}
                    </select>
                </div>
            </div>


            <div className="mt-5 mb-5">
            <button className='btn btn-danger ms-2' onClick={()=>{volver()}}>Cancelar</button>
            <input className="btn btn-success ms-2" type="submit" value={idProducto > 0? 'Actualizar' : 'Crear'} />
        </div>


        </form>

    )
};
export default Inventario;
