import axios from "axios";
import { useState } from "react";
import { Link } from "react-router-dom";
import { useEffect } from "react";
import { useForm } from "react-hook-form";

const Inventarios = () => {
  //Definicion del estado delc componente Inventarios y de funciones para su gestion
  const [inventarios, setInvetarios] = useState(null);
  const { register, handleSubmit } = useForm();

  //Definicion de la funcion para obtener los inventarios desde el servidor
  const getInventarios = async (queires = '') => {
    const { data } = await axios.get(`http://localhost:2525/inventario?${queires}`);
    setInvetarios(data);
  };

  //Definicion de la funcion que permite buscar un inventario acorde al nombre del proveedor

  const onSubmit = (data) => {
    let queries = [];
    (data.nombre_provedor_producto) && (queries.push(`nombre_provedor_producto=${data.nombre_provedor_producto}`))
    getInventarios(queries.join('&'))
  };



  //Definicion para borrar un inventario
  const deleteInventario = async (idPro, idAlm) => {
    if (window.confirm('Confirmar eliminación del inventario')) {
      await axios.delete(`http://localhost:2525/inventario/${idPro}/${idAlm}`);
      getInventarios();
    };
  };

  //Definicion de funcion para poder cargar los inventarios del servidor cuando se renderize la pagina
  useEffect(() => {
    getInventarios('');
  }
    , []);


  //Representacion de inventarios en la pantalla
  return (
    <div className="text-start">
      <h1 className="text-center">Inventarios <i className="bi bi-clipboard2-fill"></i></h1>
      {/* Aquí se insertaría el formulario para realizar la busqueda de un inventario */}

      <form onSubmit={handleSubmit(onSubmit)}>
        <fieldset>

          <div className="row">
            <div className="col-5">
              <input type="text"
                {...register('nombre_provedor_producto')}
                placeholder="Nombre del proveedor"
                className="form-control" />
            </div>
            <div className="col-2">
              <button type="submit" className="btn btn-info">
                Buscar
                <i className="bi bi-search ms-2"></i>
              </button>
            </div>
          </div>
        </fieldset>
      </form>


      {/* Aquí se insertaría una tabla para listar todos los inventarios*/}
      <table className="table table-striped  mt-5">
        <thead className="table-primary font-monospace">
          <tr>
            <th scope="col">Cantidad en stock</th>
            <th scope="col">Fecha de restock</th>
            <th scope="col">Nombre de proveedor del producto</th>
            <th scope="col">Nombre del producto</th>
            <th scope="col">Dirección del almacén</th>
            <th scope="col"><Link className="btn" to='/inventario/0/0'><i className="bi bi-plus-circle"></i>Agregar un nuevo inventario</Link></th>
          </tr>
        </thead>
        <tbody>

          {inventarios &&
            inventarios.map((inv) => {
              return (
                <tr className="table-warning" key={`${inv.id_producto}-${inv.id_almacen}`} >
                  <td >{inv.cantidad_en_stock}</td>
                  <td >{inv.fecha_de_restock}</td>
                  <td >{inv.nombre_provedor_producto}</td>
                  <td > <Link className="btn btn-link btn-sm" to={`/producto/${inv.Producto.id}`}>{inv.Producto.nombre}</Link></td>
                  <td > <Link className="btn btn-link btn-sm" to={`/almacen/${inv.Almacene.id}`}>{inv.Almacene.direccion}</Link></td>
                  <td>
                    <button
                      className="btn btn-default"
                      onClick={() => deleteInventario(inv.id_producto, inv.id_almacen)}
                    >
                      <i className="bi bi-trash-fill text-danger"></i>
                    </button>
                    <Link className="btn btn-default" to={`/inventario/${inv.id_producto}/${inv.id_almacen}`} >
                      <i className="bi bi-pencil-square text-primary"></i>
                    </Link>
                  </td>
                </tr>
              );
            })}
        </tbody>
      </table>


    </div>
  )

};

export default Inventarios;
