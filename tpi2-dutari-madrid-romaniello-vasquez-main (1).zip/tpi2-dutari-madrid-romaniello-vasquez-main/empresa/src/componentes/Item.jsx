import { useForm } from "react-hook-form";
import { useNavigate, useParams } from "react-router-dom";
import axios from "axios";
import { useEffect, useState } from "react";

function Item(){
    const {pedido_id, item_id} = useParams()
    const [item, setItem] = useState({})
    const navigate = useNavigate()
    const {register, handleSubmit, setValue, formState: {errors}} = useForm()
    const [productos, setProductos] = useState(null);
    const [producto_id, set_producto_id] = useState(null)

    async function onSubmit(data){
        if (item_id > 0) {
            await axios.put(`http://localhost:2525/item/${pedido_id}/${item_id}`, data)
        } else {
            await axios.post(`http://localhost:2525/item/${pedido_id}/`, data)
        }
        volver()

    }
    async function getItem(){
    if(item_id > 0){
        const {data} = await axios.get(`http://localhost:2525/item/${pedido_id}/${item_id}`)
        setItem(data)

        
        setValue('precio_unitario', data.precio_unitario)
        setValue('cantidad_pedida', data.cantidad_pedida)
        setValue('id_producto', data.id_producto)
        
    
    }

    }

    async function getProductos(){
        const {data} = await axios.get("http://localhost:2525/productos")
        setProductos(data)
    }

    useEffect(()=>{getItem() 
        getProductos()}, [])



    function volver(){
        navigate(`/items/${pedido_id}`)
    }
    return(
        <>
        <form onSubmit={handleSubmit(onSubmit)}>
        <div className="row mt-3">
            {item && <h1> Pedido {pedido_id} - Item: {item_id > 0? item_id : 'Nuevo'}</h1>}
        </div>

        <div className="row text-center mt-5">
                <div className="col-3 h5">
                    <label >Producto:  </label>
                </div>
                <div className="col-5">
                    <select className="form-select"
                        defaultValue={producto_id}
                        onChange={(e) => { set_producto_id(e.target.value) }}
                        {...register('id_producto')}>
                        {productos && productos.map(p => <option key={p.id} value={p.id} >{p.nombre}</option>)}
                    </select>
                </div>
            </div>

        <div className="row text-center mt-5">
            <label className="col-3 h5"> Precio Unitario: </label>
            <div className="col-5">
            <input type="text" className="form-control col-3 text-start" {...register('precio_unitario',
            {required: 'El precio es requerido', validate: (value) => {return !isNaN(value) || 'Debe ser numérico'}})}>
            </input>
            {errors.nombre && <span className='text-danger'>{errors.nombre.message}</span>}
            </div>
        </div>

        <div className="row mt-5">
            <label className="col-3 h5"> Cantidad de productos:</label>
            <div className="col-5">
            <input type="text" className="form-control col-3 text-start" {...register('cantidad_pedida', {required: 'La cantidad es requerida',
                validate: (value) => {return !isNaN(value) || 'Debe ser numérico'}
            })}></input>
            {errors.fecha_fundacion && <span className="text-danger">{errors.nombre.message}</span>}
            </div>
            
        </div>
        
        <div className="row mt-4 justify-content-center">
            <button type="submit" className="btn btn-success col-1">{item_id > 0?  'Actualizar' :'Crear'}</button>
            <button className="btn btn-danger col-1" onClick={volver} >Cancelar</button>
        </div>
        </form>

        


        </>
    )
}
export default Item