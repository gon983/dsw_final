import { useNavigate,  useParams } from "react-router-dom";
import {useState, useEffect} from "react"
import { Link } from 'react-router-dom'
import axios from 'axios'


// { item_id: 1, pedido_id: 1, id_producto: 1, precio_unitario:2500.00, cantidad_pedida: 1},

function Items(){
    const {pedido_id} = useParams() 
    const [items, setItems] = useState([])
    const navigate = useNavigate()

    async function getItems(pedido_id){
        const {data} = await axios.get(`http://localhost:2525/items/${pedido_id}`)
        setItems(data)
    }


    useEffect(()=> {getItems(pedido_id)},[pedido_id])

    function volver(){
        navigate("/pedidos")
    }

    async function deleteItem(item_id){
        if (window.confirm('¿Desea eliminar el item?'))
            await axios.delete(`http://localhost:2525/item/${pedido_id}/${item_id}`)
            getItems(pedido_id)
    }






    return (
        <>
        <div className="mt-5 d-flex justify-content-start">
                        <button className="btn btn-danger" onClick={volver}> Atras</button>

        </div>



        <table className='table table-striped  mt-5'>
                        <thead className='table-primary font-monospace'>
                            <tr>
                                <th>Item id</th>
                                <th>Precio Unitario</th>
                                <th>Cantidad Pedida</th>
                                <th>Producto</th>
                                <th>
                                    <Link className='btn' to={`/item/${pedido_id}/0`}>
                                        <i className="bi bi-plus-square"> Nuevo Item</i>
                                    </Link>
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            {items && items.map((i) => {
                                return (
                                    <tr key={i.item_id} className='table-warning'>
                                        <td>{i.item_id}</td>
                                        <td>{i.precio_unitario}</td>
                                        <td>{i.cantidad_pedida}</td>
                                        <td>{i.Producto.nombre}</td>
                                        <td>
                                            {/* boton para eliminar */}
                                            <button className="btn btn-default" onClick={() => deleteItem(i.item_id)}>
                                                <i className="bi bi-trash text-danger"></i>
                                            </button>
                                            {/* link a cada departamento particular */}
                                            <Link className="btn btn-default" to={`/item/${i.pedido_id}/${i.item_id}`}>
                                                <i className="bi bi-pencil text-primary"></i>
                                            </Link>

                                        </td>
                                    </tr>
                                )
                            }

                            )}

                        </tbody>
                    </table>
        </>
    )

}
export default Items