import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { useNavigate, useParams } from "react-router-dom";
import axios from "axios";

function Pedido() {
    const { id } = useParams();
    const navigate = useNavigate();
    const { register, handleSubmit, setValue, formState: { errors } } = useForm();
    const [pedido, setPedido] = useState({});
    const [clientes, setClientes] = useState(null);
    const [cliente_id, setCliente_id] = useState(null);

    useEffect(() => {
        getPedido(id);
        getClientes();
    }, [])

    const getPedido = async (id) => {
        if (id > 0) {
            const { data } = await axios.get(`http://localhost:2525/pedidos/${id}`)
            setPedido(data);
            setValue('id_cliente_id', data.id_cliente);
            setValue('monto', data.monto);
            setValue('fecha_pedido', data.fecha_pedido);
            setCliente_id(data.id_cliente);
        }
    }

    const getClientes = async () => {
        const { data } = await axios.get('http://localhost:2525/clientes');
        setClientes(data);
    }

    const volver = () => {
        navigate('/pedidos');
    }

    const cancelar = () => {
        volver();
    }

    const onSubmit = async (data) => {
        if (id > 0) {
            await axios.put(`http://localhost:2525/pedidos/${id}`, data)
        }
        else {
            console.log(data);
            await axios.post('http://localhost:2525/pedidos', data);
        }
        volver();
    }


    return (
        <form onSubmit={handleSubmit(onSubmit)} className='mt-5'>
            <h1 className='mb-5'>Pedido: {id > 0 ? pedido.id : 'nuevo'}</h1>

            <div className="row mt-3">
                <div className="col-4 text-end">
                    <label htmlFor="id_cliente">Cliente :</label>
                </div>
                <div className="col-8 text-start">
                    <select className="form-select"
                        defaultValue={cliente_id}
                        onChange={(e) => { setCliente_id(e.target.value) }}
                        {...register('id_cliente', {required: 'Elija un cliente.', validate: (value) => {return value != 0 || "Elija un cliente." }})}>
                        <option value='0'>Todos</option>
                        {clientes && clientes.map(c => <option key={c.id} value={c.id} >{c.apellido}</option>)}
                    </select>
                    {errors.id_cliente && <span className="text-danger">{errors.id_cliente.message}</span>}
                </div>
            </div>

            <div className="row mt-3">
                <div className="col-4 text-end">
                    <label htmlFor="fecha_pedido">Fecha:</label>
                </div>
                <div className="col-8 text-start">
                    <input type="text"
                        className='form-control'
                        {...register('fecha_pedido', { required: 'La fecha es requerida (YYYY-MM-DD)' })}
                    />
                    {errors.fecha_pedido && <span className='text-danger'>{errors.fecha_pedido.message}</span>}
                </div>
            </div>

            <div className="row mt-3">
                <div className="col-4 text-end">
                    <label htmlFor="monto">Monto:</label>
                </div>
                <div className="col-8 text-start">
                    <input type="text"
                        className='form-control'
                        {...register('monto', {
                            required: 'El monto es requerido',
                            validate: (value) => { return !isNaN(value) || 'Debe ser numérico' }
                        })}
                    />
                    {errors.monto && <span className='text-danger'>{errors.monto.message}</span>}
                </div>
            </div>



            <div className="mt-5 mb-5">
                <button className='btn btn-danger ms-2' onClick={cancelar}>Cancelar</button>
                <input className="btn btn-success ms-2" type="submit" value={id > 0 ? 'Actualizar' : 'Crear'} />
            </div>
        </form>
    )
}

export default Pedido;