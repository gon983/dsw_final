import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import axios from "axios";
import { Link } from "react-router-dom";

function Pedidos (){

    const [pedidos, setPedidos] = useState(null);
    const [clientes, setClientes] = useState(null);
    const {handleSubmit, register} = useForm();
    useEffect(() => {getPedidos();
         getClientes()}, [])


    const getPedidos = async(queries = '') => {
        const {data} = await axios.get(`http://localhost:2525/pedidos?${queries}`);
        setPedidos(data);
    }

    const getClientes = async() => {
        const {data} = await axios.get(`http://localhost:2525/clientes`);
        setClientes(data)
    }
    
    const deletePedido = async(id) =>{
        try{
        if (window.confirm("Desea borrar este pedido?")){
            await axios.delete(`http://localhost:2525/pedidos/${id}`);
            getPedidos();
        }} catch(err){
            console.log(err, "No se puede borrar un pedido con detalles.")
        }
    }

    const onSubmit = async(data) =>{
      let query = [];
      data.fecha_pedido && query.push(`fecha_pedido=${data.fecha_pedido}`);
      getPedidos(query.join('&'));
    }

    return(
        <div>
            <h1 className="">Pedidos <i className="bi bi-card-list"></i></h1>
        

            <form onSubmit={handleSubmit(onSubmit)}>
                <fieldset>
                    <legend className="text-start "> Buscar </legend>
                    <div className="row">
                        <div className="col-5">
                            <input type='text' placeholder="Fecha"
                                {...register('fecha_pedido')} className="form-control" />
                        </div>
                        <div className="col-2">
                            <button type="submit" className="btn btn-info"> Buscar <i className="bi bi-search"></i></button>
                        </div>
                    </div>

                </fieldset>
            </form>

        <table className="table table-striped  mt-5">
        <thead className="table-primary font-monospace">
          <tr>
            <th>Numero</th>
            <th>Fecha</th> 
            <th>Monto</th>
            <th>Apellido cliente</th>
            <th>Nombre cliente</th>
            <th><Link className="btn" to='/pedido/0'><i className="bi bi-plus-circle"></i> Nuevo Pedido</Link></th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {pedidos &&
            pedidos.map((p) => {
              return (
                <tr key={p.id} className="table-warning">
                  <td>{p.id}</td>
                  <td>{p.fecha_pedido}</td>
                  <td>{p.monto}</td>
                  <td>{p.Cliente.apellido}</td>
                  <td>{p.Cliente.nombre}</td>
                  <td>
                    <button
                      className="btn btn-default"
                      onClick={() => deletePedido(p.id)}
                    >
                      <i className="bi bi-trash3 text-danger"></i>
                    </button>
                    <Link className="btn btn-default" to={`/pedido/${p.id}`} >
                        <i className="bi bi-pencil text-primary"></i>
                    </Link>
                  </td>
                  <td><Link className="btn btn-default" to={`/items/${p.id}`}>Ver detalle pedido</Link></td>
                </tr>
              );
            })}
        </tbody>
      </table>
      </div>
    )
}

export default Pedidos;