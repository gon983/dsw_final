import { useForm } from "react-hook-form";
import { useNavigate, useParams } from "react-router-dom";
import axios from "axios";
import { useEffect, useState } from "react";

function Producto(){
    const {id} = useParams();
    const navigate = useNavigate();
    const {register, handleSubmit, setValue, formState: {errors}} = useForm()
    const [producto, setProducto] = useState({});

    useEffect(() => {
        getProducto(id);
    }, []);

    const getProducto = async(id) =>{
        if (id > 0){
            const {data} = await axios.get(`http://localhost:2525/productos/${id}`);
            setProducto(data);
            setValue('nombre', data.nombre);
            setValue('precio', data.precio);
            setValue('fecha_ingreso', data.fecha_ingreso);
        }
    }

    const volver = () => {
        navigate('/productos');
    }

    const cancelar = () =>{
        volver();
    }

    const onSubmit = async(data) => {
        if (id > 0) {
            axios.put(`http://localhost:2525/productos/${id}`, data)
        } else {
            axios.post(`http://localhost:2525/productos/`, data)
        }

        volver();
    }

    return(
        <form onSubmit={handleSubmit(onSubmit)} className="mt-5">
            <h1 className='mb-5'>Producto: {id > 0? producto.nombre : 'Nuevo'}</h1>
            <div className="row mt-3">
                <div className="col-4 text-end">
                    <label htmlFor="nombre">Nombre:</label>
                </div>
                <div className="col-8 text-start">
                    <input type="text" 
                    className='form-control'
                    {...register('nombre', {required: 'El nombre es requerido'})}
                    />
                    {errors.nombre && <span className='text-danger'>{errors.nombre.message}</span>}
                </div>
            </div>
           
            <div className="row mt-3">
                <div className="col-4 text-end">
                    <label htmlFor="precio">Precio:</label>
                </div>
                <div className="col-8 text-start">
                    <input type="text" 
                    className='form-control'
                    {...register('precio', {required: 'El precio es requerido', 
                        validate: (value) => {return !isNaN(value) || 'Debe ser numérico'} })}
                    />
                    {errors.precio && <span className='text-danger'>{errors.precio.message}</span>}
                </div>
            </div>

            <div className="row mt-3">
                <div className="col-4 text-end">
                    <label htmlFor="fecha_ingreso">Fecha de ingreso:</label>
                </div>
                <div className="col-8 text-start">
                    <input type="text" 
                    className='form-control'
                    {...register('fecha_ingreso', {required: 'La fecha de ingreso es requerida'})}
                    />
                    {errors.fecha_ingreso && <span className='text-danger'>{errors.fecha_ingreso.message}</span>}
                </div>
            </div>


            <div className="mt-5 mb-5">
            <button className='btn btn-danger ms-2' onClick={cancelar}>Cancelar</button>
            <input className="btn btn-success ms-2" type="submit" value={id > 0? 'Actualizar' : 'Crear'} />

        </div>


        </form>
    )
}

export default Producto;