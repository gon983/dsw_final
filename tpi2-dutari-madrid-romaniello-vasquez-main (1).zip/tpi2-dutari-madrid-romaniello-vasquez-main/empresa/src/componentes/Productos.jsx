import axios from "axios";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { Link } from "react-router-dom";

function Productos() {
    const [productos, setProductos] = useState(null);
    const { register, handleSubmit } = useForm();
    useEffect(() => {
        getProductos();
    }, []);

    const getProductos = async (queries = '') => {
        const { data } = await axios.get(`http://localhost:2525/productos?${queries}`);
        setProductos(data);
    }

    const deleteProducto = async (id) => {
        if (window.confirm('Desea borrar este producto?')) {
            await axios.delete(`http://localhost:2525/productos/${id}`);
            getProductos();
        }
    }

    const onSubmit = async (data) => {
        let query = [];
        data.nombre && query.push(`nombre=${data.nombre}`)
        getProductos(query.join('&'));
    }

    return (
        <div className="text-start">
            <h1 className="text-center">Productos <i className="bi bi-cart"></i></h1>

            <form onSubmit={handleSubmit(onSubmit)}>
                <fieldset>
                    <legend className="text-start "> Buscar </legend>
                    <div className="row">
                        <div className="col-5">
                            <input type='text' placeholder="Nombre"
                                {...register('nombre')} className="form-control" />
                        </div>
                        <div className="col-2">
                            <button type="submit" className="btn btn-info"> Buscar <i className="bi bi-search"></i></button>
                        </div>
                    </div>

                </fieldset>
            </form>


            <table className="table table-striped  mt-5">
                <thead className="table-primary font-monospace">
                    <tr>
                        <th>Nombre</th>
                        <th>Precio</th>
                        <th>Fecha de ingreso</th>
                        <th><Link className="btn text-" to='/producto/0'><i className="bi bi-plus-circle"></i> Nuevo Producto</Link></th>
                    </tr>
                </thead>
                <tbody>
                    {productos && productos.map((p) => {
                        return (
                            <tr key={p.id} className="table-warning">
                                <td>{p.nombre}</td>
                                <td>{p.precio}</td>
                                <td>{p.fecha_ingreso}</td>
                                <td>
                                    <button className="btn btn-default" onClick={() => { deleteProducto(p.id) }}>
                                        <i className="bi bi-trash text-danger"></i>
                                    </button>
                                    <Link className="btn btn-default" to={`/producto/${p.id}`}>
                                        <i className="bi bi-pencil text-primary"></i>
                                    </Link>
                                </td>
                            </tr>
                        )
                    })}
                </tbody>
            </table>
        </div>
    )
}

export default Productos;